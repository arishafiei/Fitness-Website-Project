# Fitness Website Project

## Overview
This project was developed during my internship at Studienkolleg as part of a group web design project. It represents a fitness-themed website designed using HTML, CSS, and PHP.

## Features
- Modern responsive design
- Navigation between pages
- Basic PHP-based backend functionality
- Fitness and wellness content

## Technologies Used
- HTML5  
- CSS3  
- PHP  

## How to Run
1. Download or clone this repository.
2. Place the folder inside your local web server directory (e.g., `htdocs` for XAMPP).
3. Start your Apache server.
4. Open your browser and go to:  
   `http://localhost/Fitness-Website-Project`

## Preview
*(Add your website screenshots here)*

## Contributor
**Ariana Shafiei Baghbaderani**
